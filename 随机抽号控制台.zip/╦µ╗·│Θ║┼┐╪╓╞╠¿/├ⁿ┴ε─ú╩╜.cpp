#include <bits/stdc++.h>
#include <windows.h>
using namespace std;
string cm,kid;
void kill()
{
	cin>>kid;
}
void copy()
{
	cin>>kid;
}
void imfoantirand()
{
	cin>>kid;
}
void del()
{
	cin>>kid;
}
void close()
{
	cin>>kid;
	if(kid=="all") {
		system("del c:\randtemp.exe /f");
		system("taskkill /f /im ������2.0����̨.exe");
		Sleep(20);
	}
	if(kid=="without") {
		system("taskkill /f /im ������2.0����̨.exe");
	}
}
void error()
{
	cout<<"����ָ���"<<endl;
	Sleep(20);
	system("pause");
	system("cls");
}
void fire()
{
	cin>>kid;
	if(kid=="50"){
	system("start ����ٳ�������fire50.reg");
	} 
}
int main()
{
	while(1)
	{
		cin>>cm;
		if(cm=="del"){
			del();
			system("pause");
			system("cls");
			continue;
		} 
		
		if(cm=="close"){
			close();
			system("pause");
			system("cls");
			continue;
		} 
		
		if(cm=="copy"){
			copy();
			system("pause");
			system("cls");
			continue;
		} 
		
		if(cm=="kill"){
			kill();
			system("pause");
			system("cls");
			continue;
		}
		
		if(cm=="exit"){
			cout<<"�����˳�"<<endl;
			Sleep(2000);
			return 0;
		} 
		
		if(cm=="fire") {
			fire();
			system("pause");
			system("cls");
			continue;
		}
		error(); 
	}
	
	
	return 0;
}

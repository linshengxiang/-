#include <bits/stdc++.h>
using namespace std;
int main()
{
	system("taskkill /f /im ������.exe");
	system("taskkill /f /im randtemp.exe");
	return 0;
}

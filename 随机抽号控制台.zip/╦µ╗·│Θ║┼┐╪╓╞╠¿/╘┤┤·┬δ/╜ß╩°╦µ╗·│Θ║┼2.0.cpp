#include <bits/stdc++.h>
using namespace std;
int main()
{
	system("taskkill /f /im ������2.0.exe");
	return 0;
}
